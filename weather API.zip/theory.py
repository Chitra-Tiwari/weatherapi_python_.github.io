#wedgets
#lavel
#button
# "C:/Users/Danny/Desktop/pythonproject/images/weatherlast.png
# ="C:/Users/Danny/Desktop/pythonproject/images/weather2.png"